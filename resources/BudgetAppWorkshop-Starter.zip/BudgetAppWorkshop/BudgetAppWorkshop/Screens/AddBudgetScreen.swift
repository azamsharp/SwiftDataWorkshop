//
//  AddBudgetScreen.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import SwiftUI

struct AddBudgetScreen: View {
    
    @Environment(\.dismiss) private var dismiss
    
    @State private var name: String = ""
    @State private var limit: Double?
    @State private var errorMessage: String = ""
    
    private var isFormValid: Bool {
        return true 
    }
    
    var body: some View {
        Form {
            TextField("Name", text: $name)
                .accessibilityIdentifier("budgetNameTextField")
            TextField("Limit", value: $limit, format: .number)
                .accessibilityIdentifier("budgetLimitTextField")
            Text(errorMessage)
        }.toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Save") {
                    // if form is valid
                    // save budget
                }.disabled(!isFormValid)
                    .accessibilityIdentifier("saveBudgetButton")
            }
        }
    }
}

#Preview { @MainActor in
    NavigationStack {
        AddBudgetScreen()
    }
}
