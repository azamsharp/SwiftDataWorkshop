//
//  Double+Extensions.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import Foundation

extension Double {
    
    var isPositive: Bool {
        self > 0 
    }
    
}
