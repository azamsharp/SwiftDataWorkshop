//
//  BudgetListScreen.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import SwiftUI
import SwiftData

struct BudgetListScreen: View {
    
    @State private var isPresented: Bool = false
    
    var body: some View {
        List(1...10, id: \.self) { _ in
            Text("Display List of all Budgets")
        }
        .accessibilityIdentifier("budgetCollectionView")
        .listStyle(.plain)
            .navigationTitle("Budgets")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add Budget") {
                        isPresented = true
                    }.accessibilityIdentifier("addBudgetButton")
                }
            }
            .sheet(isPresented: $isPresented, content: {
                NavigationStack {
                    Text("Show Add Budget Screen")
                }
            })
            
    }
}

#Preview {
    NavigationStack {
        BudgetListScreen()
    }
}

/*
struct BudgetCellView: View {
    
    let budget: Budget
    
    var body: some View {
        HStack {
            Text(budget.name)
            Spacer()
            Text(budget.limit, format: .currency(code: Locale.currencyCode))
        }
    }
} */
