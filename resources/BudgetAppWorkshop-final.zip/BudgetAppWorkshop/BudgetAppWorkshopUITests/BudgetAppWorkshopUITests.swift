//
//  BudgetAppWorkshopUITests.swift
//  BudgetAppWorkshopUITests
//
//  Created by Mohammad Azam on 4/3/24.
//

import XCTest
@testable import BudgetAppWorkshop

final class BudgetAppWorkshopUITests: XCTestCase {

    private var app: XCUIApplication!
    
    override func setUp() {
        app = XCUIApplication()
        
        // setup launch arguments
        app.launchArguments = ["UITEST"]
        app.launch()
    }
    
    func testAddBudget() throws {
        
        app.navigationBars["Budgets"]/*@START_MENU_TOKEN@*/.buttons["addBudgetButton"]/*[[".otherElements[\"Add Budget\"]",".buttons[\"Add Budget\"]",".buttons[\"addBudgetButton\"]",".otherElements[\"addBudgetButton\"]"],[[[-1,2],[-1,1],[-1,3,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.tap()
        
        // create budget
        app.textFields["budgetNameTextField"]
            .tap()
        
        app.textFields["budgetNameTextField"]
            .typeText("Groceries")
        
        app.textFields["budgetLimitTextField"]
            .tap()
           
        app.textFields["budgetLimitTextField"]
            .typeText("200")
        
        app.buttons["saveBudgetButton"]
            .tap()
        
        XCTAssertTrue(app.collectionViews["budgetCollectionView"].staticTexts["Groceries"].exists)
        
        //app.collectionViews["budgetTable"]/*@START_MENU_TOKEN@*/.staticTexts["Fffff"]/*[[".cells",".buttons[\"Fffff, $44.00\"].staticTexts[\"Fffff\"]",".staticTexts[\"Fffff\"]"],[[[-1,2],[-1,1],[-1,0,1]],[[-1,2],[-1,1]]],[0]]@END_MENU_TOKEN@*/.tap()
          //  .typeText("200")
        
       
            
    }
    
}
