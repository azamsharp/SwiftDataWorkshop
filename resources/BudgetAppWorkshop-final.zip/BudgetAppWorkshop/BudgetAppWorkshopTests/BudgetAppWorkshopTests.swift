//
//  BudgetAppWorkshopTests.swift
//  BudgetAppWorkshopTests
//
//  Created by Mohammad Azam on 3/28/24.
//

import XCTest
import SwiftData
@testable import BudgetAppWorkshop

final class WhenAddingBudgetWithExpenses: XCTestCase {

    private var context: ModelContext!
    private var budget: Budget!
    
    @MainActor
    override func setUp() {
        context = mockContainer.mainContext
        
        // create budget with expenses
        budget = Budget(name: "Groceries", limit: 500)
        context.insert(budget)
        
        // add expenses
        let expenses = [Expense(name: "Milk", price: 10.0, quantity: 1), Expense(name: "Bread", price: 2.50, quantity: 4), Expense(name: "Eggs", price: 2.00, quantity: 12)]
        budget.expenses = expenses
    }
    
    func testCalculateBudgetSpent() {
        XCTAssertEqual(44, budget.spent)
    }
    
    func testCalculateBudgetRemaining() {
        
        XCTAssertEqual(456, budget.remaining)
    }
    
    func testDuplicateBudgetNameThrowException() {
        
        let duplicateBudget = Budget(name: "Groceries", limit: 700)
        
        XCTAssertThrowsError(try duplicateBudget.save(context: context)) { error in
            XCTAssertEqual(BudgetError.duplicateName, error as? BudgetError)
        }
    }
}
