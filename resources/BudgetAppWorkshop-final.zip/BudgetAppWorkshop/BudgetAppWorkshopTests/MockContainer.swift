//
//  PreviewContainer.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import Foundation
import SwiftData
@testable import BudgetAppWorkshop


@MainActor
var mockContainer: ModelContainer = {
    
    let container = try! ModelContainer(for: Budget.self, configurations: ModelConfiguration(isStoredInMemoryOnly: true))
    return container
    
}()
