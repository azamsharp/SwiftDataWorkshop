//
//  BudgetSchemaV2.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/28/24.
//

import Foundation
import SwiftData

enum BudgetSchemaV2: VersionedSchema {
    
    static var versionIdentifier = Schema.Version(2, 0, 0)
    
    static var models: [any PersistentModel.Type] {
        [Budget.self, Expense.self]
    }
    
    @Model
    class Budget {
        
        // unique is not going to work when iCloud sync is enabled
       // @Attribute(.unique)
        var name: String
        var limit: Double
        
        @Relationship(deleteRule: .cascade)
        var expenses: [Expense] = []
        
        init(name: String, limit: Double) {
            self.name = name
            self.limit = limit
        }
    }
    
}
