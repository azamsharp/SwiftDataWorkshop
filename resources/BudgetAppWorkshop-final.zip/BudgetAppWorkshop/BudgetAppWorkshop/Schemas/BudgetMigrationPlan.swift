//
//  BudgetMigrationPlan.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/28/24.
//

import Foundation
import SwiftData

enum BudgetMigrationPlan: SchemaMigrationPlan {
    
    static var stages: [MigrationStage] {
        [migrateV1toV2]
    }
    
    static var schemas: [any VersionedSchema.Type] {
        [BudgetSchemaV1.self, BudgetSchemaV2.self]
    }
    
    static let migrateV1toV2 = MigrationStage.lightweight(fromVersion: BudgetSchemaV1.self, toVersion: BudgetSchemaV2.self)
}
