//
//  BudgetSchemaV1.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/28/24.
//

import Foundation
import SwiftData

enum BudgetSchemaV1: VersionedSchema {
    
    static var versionIdentifier = Schema.Version(1, 0, 0)
    
    static var models: [any PersistentModel.Type] {
        [Budget.self]
    }
    
    @Model
    class Budget {
        
        // unique is not going to work when iCloud sync is enabled
        //@Attribute(.unique)
        var name: String
        var limit: Double
        
        @Relationship(deleteRule: .cascade)
        var expenses: [Expense] = []
        
        init(name: String, limit: Double) {
            self.name = name
            self.limit = limit
        }
    }
    
}

/*
 enum UsersSchemaV1: VersionedSchema {
     static var versionIdentifier = Schema.Version(1, 0, 0)

     static var models: [any PersistentModel.Type] {
         [User.self]
     }

     @Model
     class User {
         var name: String
         var age: Int

         init(name: String, age: Int) {
             self.name = name
             self.age = age
         }
     }
 }
 */
