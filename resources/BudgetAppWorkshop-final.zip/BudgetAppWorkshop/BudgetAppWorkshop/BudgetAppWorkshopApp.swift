//
//  BudgetAppWorkshopApp.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import SwiftUI
import SwiftData

@main
struct BudgetAppWorkshopApp: App {
    
    let container: ModelContainer
    
    init() {
        do {
            container = try ModelContainer(for: Budget.self, migrationPlan: BudgetMigrationPlan.self, configurations: ModelConfiguration(for: Budget.self))
            
            // if the test is running then make sure to delete everything from the database 
            if ProcessInfo.processInfo.arguments.contains("UITEST") {
                // delete all records
                try container.mainContext.delete(model: Budget.self)
                try container.mainContext.delete(model: Expense.self)
            }
            
        } catch {
            fatalError("Could not initialize the container.")
        }
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                BudgetListScreen()
            }.modelContainer(container)
        }
    }
}
