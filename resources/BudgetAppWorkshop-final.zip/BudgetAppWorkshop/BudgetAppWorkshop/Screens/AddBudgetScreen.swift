//
//  AddBudgetScreen.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import SwiftUI

struct AddBudgetScreen: View {
    
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    
    @State private var name: String = ""
    @State private var limit: Double?
    @State private var errorMessage: String = ""
    
    private var isFormValid: Bool {
        
        guard let limit = limit else { return false }
        return !name.isEmptyOrWhitespace && limit.isPositive
    }
    
    private func saveBudget() {
        
        guard let limit = limit else { return }
        
        let budget = Budget(name: name, limit: limit)
        do {
            try budget.save(context: context)
            dismiss() 
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    var body: some View {
        Form {
            TextField("Name", text: $name)
                .accessibilityIdentifier("budgetNameTextField")
            TextField("Limit", value: $limit, format: .number)
                .accessibilityIdentifier("budgetLimitTextField")
            Text(errorMessage)
        }.toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Save") {
                    if isFormValid {
                        saveBudget()
                    }
                }.disabled(!isFormValid)
                    .accessibilityIdentifier("saveBudgetButton")
            }
        }
    }
}

#Preview { @MainActor in
    NavigationStack {
        AddBudgetScreen()
    }.modelContainer(previewContainer)
}
