//
//  BudgetListScreen.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import SwiftUI
import SwiftData

struct BudgetListScreen: View {
    
    @Environment(\.modelContext) private var context
    
    @State private var isPresented: Bool = false
    @Query private var budgets: [Budget]
    
    // total of all budgets. This property is only used in the View
    private var budgetTotal: Double {
        budgets.reduce(0) { limit, budget in
            budget.limit + limit
        }
    }
    
    private func deleteBudget(_ indexSet: IndexSet) {
        indexSet.forEach { index in
            let budget = budgets[index]
            context.delete(budget)
        }
    }
    
    var body: some View {
        List {
            ForEach(budgets) { budget in
                
                NavigationLink {
                    BudgetDetailScreen(budget: budget)
                } label: {
                    BudgetCellView(budget: budget)
                }.buttonStyle(PlainButtonStyle())
                
            }.onDelete(perform: deleteBudget)
            
            
            if !budgets.isEmpty {
                HStack {
                    Spacer()
                    Text("Total:")
                    Text(budgetTotal, format: .currency(code: Locale.currencyCode))
                    Spacer()
                }
            }
             
        }
        .accessibilityIdentifier("budgetCollectionView")
        .listStyle(.plain)
            .navigationTitle("Budgets")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add Budget") {
                        isPresented = true
                    }.accessibilityIdentifier("addBudgetButton")
                }
            }
            .sheet(isPresented: $isPresented, content: {
                NavigationStack {
                    AddBudgetScreen()
                }
            })
            .overlay(alignment: .center) {
                if budgets.isEmpty {
                    ContentUnavailableView("No budgets found.", systemImage: "tray.fill")
                }
            }
    }
}

#Preview { @MainActor in
    NavigationStack {
        BudgetListScreen()
    }.modelContainer(previewContainer)
}

struct BudgetCellView: View {
    
    let budget: Budget
    
    var body: some View {
        HStack {
            Text(budget.name)
            Spacer()
            Text(budget.limit, format: .currency(code: Locale.currencyCode))
        }
    }
}
