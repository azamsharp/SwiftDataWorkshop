//
//  BudgetDetailScreen.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/27/24.
//

import SwiftUI
import SwiftData

struct BudgetDetailScreen: View {
    
    @Bindable var budget: Budget
    @Environment(\.modelContext) private var context
    
    @State private var expenseConfig = ExpenseConfig()
    @State private var isPresented: Bool = false
    
    @Query private var expenses: [Expense] = []
    
    init(budget: Budget) {
        
        self.budget = budget
        let budgetId = self.budget.persistentModelID
        
        let predicate = #Predicate<Expense> {
            if let budget = $0.budget {
                return budget.persistentModelID == budgetId
            } else {
                return false
            }
        }
        
        _expenses = Query(filter: predicate)
    }
    
    private func deleteExpense(_ indexSet: IndexSet) {
        
        indexSet.forEach { index in
            let expense = expenses[index]
            context.delete(expense)
        }
    }
    
    var body: some View {
        
        VStack {

            Text(budget.limit, format: .currency(code: Locale.currencyCode))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .font(.headline)
            
            Form {
                Section("Budget") {
                     TextField("Budget name", text: $budget.name)
                     TextField("Budget limit", value: $budget.limit, format: .currency(code: Locale.currencyCode))
                }
                
                Section("Expenses") {
                    List {
                        
                        VStack {
                            Text("Total: \(Text(budget.spent, format: .currency(code: Locale.currencyCode)))")
                                .frame(maxWidth: .infinity, alignment: .center)
                            Text("Remaining: \(Text(budget.remaining, format: .currency(code: Locale.currencyCode)))")
                                .frame(maxWidth: .infinity, alignment: .center)
                        }
                        
                        ForEach(expenses) { expense in
                            ExpenseCellView(expense: expense)
                        }.onDelete(perform: deleteExpense)
                    }
                }
                
            }.navigationTitle(budget.name)
        }.toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Add Expense") {
                    isPresented = true
                }
            }
        }.sheet(isPresented: $isPresented) {
            AddExpenseScreen(budget: budget)
        }
        
    }
}

struct BudgetDetailScreenContainer: View {
    
    @Query(sort: \Budget.name, order: .forward) private var budgets: [Budget]
    
    var body: some View {
        // SampleData.budgets simple returns a hard-coded array of budgets
        BudgetDetailScreen(budget: budgets[0])
    }
}

#Preview { @MainActor in
    NavigationStack {
        BudgetDetailScreenContainer()
    }.modelContainer(previewContainer)
}

/*
 #Preview { @MainActor in
 NavigationStack {
 // this causes failed to find a currently active container for Budget error
 BudgetDetailScreen(budget: SampleData.budgets[0])
 }.modelContainer(previewContainer)
 } */

struct ExpenseCellView: View {
    
    let expense: Expense
    
    var body: some View {
        HStack {
            Text("\(Text(expense.name)) (\(expense.quantity))")
            Spacer()
            Text(expense.total, format: .currency(code: Locale.currencyCode))
        }
    }
}
