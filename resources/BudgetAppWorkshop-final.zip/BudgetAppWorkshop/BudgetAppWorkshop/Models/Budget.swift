//
//  Budget.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/26/24.
//

import Foundation
import SwiftData

typealias Budget = BudgetSchemaV2.Budget

extension Budget {
    
    var spent: Double {
        expenses.reduce(0) { price, expense in
            price + (expense.price * Double(expense.quantity))
        }
    }
    
    var remaining: Double {
        limit - spent
    }
    
    func save(context: ModelContext) throws {
        
        let fetchDescriptor = FetchDescriptor<Budget>(predicate: #Predicate { $0.name == name })
        let budgets: [Budget] = try context.fetch(fetchDescriptor)
        
        if !budgets.isEmpty {
            throw BudgetError.duplicateName
        }
        
        context.insert(self)
    }
}

/*
 @Model
 class Budget {
 
 // unique is not going to work when iCloud sync is enabled
 //@Attribute(.unique)
 var name: String
 var limit: Double
 
 @Relationship(deleteRule: .cascade)
 var expenses: [Expense] = []
 
 init(name: String, limit: Double) {
 self.name = name
 self.limit = limit
 }
 
 var spent: Double {
 expenses.reduce(0) { price, expense in
 price + (expense.price * Double(expense.quantity))
 }
 }
 
 var remaining: Double {
 limit - spent
 }
 
 func save(context: ModelContext) throws {
 
 let fetchDescriptor = FetchDescriptor<Budget>(predicate: #Predicate { $0.name == name })
 let budgets: [Budget] = try context.fetch(fetchDescriptor)
 
 if !budgets.isEmpty {
 throw BudgetError.duplicateName
 }
 
 context.insert(self)
 }
 }
 
 */
